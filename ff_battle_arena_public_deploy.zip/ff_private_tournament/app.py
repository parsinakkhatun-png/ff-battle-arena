from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, secrets
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-hosting")
DB = os.path.join(os.path.dirname(__file__), "tournament.db")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-me-now")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS tournaments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            game_mode TEXT NOT NULL, match_date TEXT NOT NULL,
            slots INTEGER NOT NULL, prize TEXT DEFAULT '', status TEXT DEFAULT 'Open',
            room_id TEXT DEFAULT '', room_password TEXT DEFAULT '')""")
        con.execute("""CREATE TABLE IF NOT EXISTS teams(
            id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL,
            team_name TEXT NOT NULL, captain TEXT NOT NULL, contact TEXT NOT NULL,
            players TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def home():
    with db() as con:
        tournaments = con.execute("SELECT * FROM tournaments ORDER BY match_date").fetchall()
        counts = {r["id"]: con.execute("SELECT COUNT(*) FROM teams WHERE tournament_id=?", (r["id"],)).fetchone()[0] for r in tournaments}
    return render_template("home.html", tournaments=tournaments, counts=counts)

@app.route("/register/<int:tid>", methods=["GET", "POST"])
def register(tid):
    with db() as con:
        t = con.execute("SELECT * FROM tournaments WHERE id=?", (tid,)).fetchone()
        if not t: return "Tournament not found", 404
        count = con.execute("SELECT COUNT(*) FROM teams WHERE tournament_id=?", (tid,)).fetchone()[0]
        if request.method == "POST":
            if t["status"] != "Open" or count >= t["slots"]:
                flash("Registration is closed or all slots are filled.")
                return redirect(url_for("home"))
            team = request.form.get("team_name","").strip()
            captain = request.form.get("captain","").strip()
            contact = request.form.get("contact","").strip()
            players = request.form.get("players","").strip()
            if not all([team, captain, contact, players]):
                flash("Please complete every field.")
                return redirect(url_for("register", tid=tid))
            con.execute("INSERT INTO teams(tournament_id,team_name,captain,contact,players) VALUES(?,?,?,?,?)",
                        (tid, team, captain, contact, players))
            flash("Team registered! Check with the organiser for match updates.")
            return redirect(url_for("home"))
    return render_template("register.html", tournament=t, count=count)

@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if session.get("admin"): return redirect(url_for("dashboard"))
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("password",""), ADMIN_PASSWORD):
            session["admin"] = True
            return redirect(url_for("dashboard"))
        flash("Incorrect password.")
    return render_template("login.html")

@app.route("/admin/dashboard")
@admin_required
def dashboard():
    with db() as con:
        tournaments = con.execute("SELECT * FROM tournaments ORDER BY id DESC").fetchall()
        teams = con.execute("""SELECT teams.*, tournaments.title FROM teams
                               JOIN tournaments ON teams.tournament_id=tournaments.id
                               ORDER BY teams.id DESC""").fetchall()
    return render_template("dashboard.html", tournaments=tournaments, teams=teams)

@app.route("/admin/create", methods=["POST"])
@admin_required
def create():
    title=request.form.get("title","").strip()
    mode=request.form.get("game_mode","Squad")
    date=request.form.get("match_date","")
    slots=request.form.get("slots","")
    prize=request.form.get("prize","").strip()
    if title and date and slots.isdigit() and int(slots)>0:
        with db() as con:
            con.execute("INSERT INTO tournaments(title,game_mode,match_date,slots,prize) VALUES(?,?,?,?,?)",
                        (title,mode,date,int(slots),prize))
        flash("Tournament created.")
    else: flash("Enter a title, date and valid slot count.")
    return redirect(url_for("dashboard"))

@app.route("/admin/room/<int:tid>", methods=["POST"])
@admin_required
def room(tid):
    with db() as con:
        con.execute("UPDATE tournaments SET room_id=?, room_password=? WHERE id=?",
                    (request.form.get("room_id","").strip(), request.form.get("room_password","").strip(), tid))
    flash("Room details updated.")
    return redirect(url_for("dashboard"))

@app.route("/admin/status/<int:tid>", methods=["POST"])
@admin_required
def status(tid):
    value=request.form.get("status")
    if value in ["Open","Closed","Completed"]:
        with db() as con: con.execute("UPDATE tournaments SET status=? WHERE id=?", (value,tid))
    return redirect(url_for("dashboard"))

@app.route("/admin/delete/<int:tid>", methods=["POST"])
@admin_required
def delete(tid):
    with db() as con:
        con.execute("DELETE FROM teams WHERE tournament_id=?", (tid,))
        con.execute("DELETE FROM tournaments WHERE id=?", (tid,))
    flash("Tournament and registrations deleted.")
    return redirect(url_for("dashboard"))

@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

# Initialize the database for both local use and production WSGI servers.
init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
