# FF Battle Arena — private tournament website

## Features
- Public tournament listing and team registration
- Solo, Duo and Squad modes
- Admin login and tournament creation
- Open / Closed / Completed status
- Admin-only private room ID and password management
- SQLite database

## Run in Termux (Android)
1. Install Python from your Termux package manager if needed:
   `pkg update && pkg install python`
2. Extract this ZIP and enter the project folder:
   `cd ff_private_tournament`
3. Install requirements:
   `pip install -r requirements.txt`
4. Set a private admin password before starting:
   `export ADMIN_PASSWORD='your-long-private-password'`
   `export SECRET_KEY='use-a-long-random-secret-string'`
5. Start:
   `python app.py`
6. Open `http://127.0.0.1:5000` in Chrome on the same phone.
7. Admin: `http://127.0.0.1:5000/admin`

Default admin password is `change-me-now` if you do not set ADMIN_PASSWORD. Change it before use.

## Important before public hosting
This is a starter project, not production-hardened. Use HTTPS, a strong SECRET_KEY and ADMIN_PASSWORD, CSRF protection, rate limiting, secure backups, and a production WSGI server. Do not publish private room credentials on public pages. Admin dashboard is password-protected but should be further hardened before public deployment. Collect only information you need and protect player contact details.

This is an unofficial community tool and is not affiliated with or endorsed by Garena. Use only official game clients and follow Free Fire's rules. No cheats, injectors, account trading, or unauthorised access are provided.


## Deploy publicly with Render
1. Push this project folder to a GitHub repository (do not upload `.env` or secrets).
2. In Render, choose **New → Web Service** and connect that repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Add environment variables `ADMIN_PASSWORD` and `SECRET_KEY` in Render's Environment settings.
6. Deploy, then open the `onrender.com` URL Render provides.

**Database warning:** this starter uses SQLite stored in the app folder. Many free hosting instances have ephemeral storage, so registrations may be lost on redeploy/restart. For a real public tournament, attach persistent storage or migrate to a managed PostgreSQL database before collecting registrations. Do not share private room passwords publicly.
